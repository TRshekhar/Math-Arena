import { useState } from 'react';
import { useCSS } from './hooks/useCSS';
import { useSocketGame } from './hooks/useSocketGame';
import { DEFAULT_Q, shuffle } from './constants/gameData';

import IntroScreen  from './components/IntroScreen';
import AdminPanel   from './components/AdminPanel';
import SetupScreen  from './components/SetupScreen';
import QRLobby      from './components/QRLobby';
import GameScreen   from './components/GameScreen';
import ResultScreen from './components/ResultScreen';

export default function App() {
  useCSS();

  // ── Global socket — lives here so it NEVER disconnects on screen change ──
  const socketGame = useSocketGame();

  const [screen,     setScreen]     = useState('intro');
  const [questions,  setQuestions]  = useState(DEFAULT_Q);
  const [gameConfig, setGameConfig] = useState(null);
  const [result,     setResult]     = useState(null);

  const getGameQ = (count) => shuffle(questions).slice(0, count);

  const handleBegin = (cfg) => {
    setGameConfig(cfg);
    setScreen(cfg.mode === 'qr' ? 'qrlobby' : 'game');
  };

  const handleGameEnd = (res) => {
    setResult(res);
    setScreen('result');
  };

  /* ── Screens ── */
  if (screen === 'intro') return (
    <IntroScreen
      onQuickPlay={() => setScreen('setup')}
      onCustomContest={() => setScreen('admin')}
    />
  );

  if (screen === 'admin') return (
    <AdminPanel
      questions={questions}
      setQuestions={setQuestions}
      onStart={() => setScreen('setup')}
      onBack={() => setScreen('intro')}
    />
  );

  if (screen === 'setup') return (
    <SetupScreen
      questions={questions}
      onBack={() => setScreen('intro')}
      onBegin={handleBegin}
    />
  );

  if (screen === 'qrlobby') return (
    <QRLobby
      teams={{ t1: gameConfig.t1, t2: gameConfig.t2 }}
      socketGame={socketGame}           
      onStartGame={() => setScreen('game')}
      onBack={() => setScreen('setup')}
    />
  );

  if (screen === 'game') return (
    <GameScreen
      key={gameConfig.t1 + gameConfig.t2}
      teams={{ t1: gameConfig.t1, t2: gameConfig.t2 }}
      questions={getGameQ(gameConfig.qCount)}
      onEnd={handleGameEnd}
      onBack={() => setScreen('setup')}
      socketGame={gameConfig.mode === 'qr' ? socketGame : null}
      session={gameConfig.mode === 'qr' ? socketGame.sessionCode : null}
    />
  );

  if (screen === 'result') return (
    <ResultScreen
      result={result}
      teams={{ t1: gameConfig.t1, t2: gameConfig.t2 }}
      onPlayAgain={() => setScreen('game')}
      onHome={() => setScreen('intro')}
    />
  );

  return null;
}
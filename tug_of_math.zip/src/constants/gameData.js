export const T1_COLOR = '#00e676';
export const T2_COLOR = '#ff1744';
export const AC_COLOR = '#40c4ff';
export const BG_DARK  = '#060f1e';
export const BG_MID   = '#0a1830';
export const BG_CARD  = '#0f2040';

export const ROPE_STEP = 14;
export const WIN_L     = 12;
export const WIN_R     = 88;
export const Q_TIME    = 25;   // global fallback timer (seconds)

export const DIFF_COL = { easy: '#69f0ae', medium: '#ffab40', hard: '#ff5252' };

export const uid     = () => Math.random().toString(36).slice(2, 9);
export const shuffle = a  => [...a].sort(() => Math.random() - 0.5);

// Each question may have its own `timer` (seconds). Falls back to Q_TIME if absent.
export const DEFAULT_Q = [
  { id:'q1',  type:'mcq', q:'15 × 8 = ?',                             opts:['100','120','125','140'],   ans:'120',  diff:'easy',   cat:'Arithmetic',   timer:15 },
  { id:'q2',  type:'mcq', q:'Solve for x:  2x + 5 = 17',             opts:['4','5','6','7'],            ans:'6',    diff:'medium', cat:'Algebra',      timer:20 },
  { id:'q3',  type:'sub', q:'√144 = ?',                                ans:'12',  diff:'easy',   cat:'Arithmetic',   timer:15 },
  { id:'q4',  type:'mcq', q:'d/dx (x²) = ?',                          opts:['x','2x','2','x³'],         ans:'2x',   diff:'hard',   cat:'Calculus',     timer:30 },
  { id:'q5',  type:'sub', q:'17 × 13 = ?',                             ans:'221', diff:'medium', cat:'Arithmetic',   timer:20 },
  { id:'q6',  type:'mcq', q:'log₁₀(1000) = ?',                        opts:['2','3','4','10'],          ans:'3',    diff:'hard',   cat:'Logarithms',   timer:30 },
  { id:'q7',  type:'sub', q:'12² − 11² = ?',                           ans:'23',  diff:'medium', cat:'Algebra',      timer:20 },
  { id:'q8',  type:'mcq', q:'Sum of angles in a triangle = ?',        opts:['90°','180°','270°','360°'], ans:'180°', diff:'easy',   cat:'Geometry',     timer:15 },
  { id:'q9',  type:'sub', q:'6! = ?',                                   ans:'720', diff:'medium', cat:'Combinatorics',timer:25 },
  { id:'q10', type:'mcq', q:'Which is a prime number?',                opts:['51','57','59','63'],       ans:'59',   diff:'medium', cat:'Number Theory', timer:20 },
  { id:'q11', type:'sub', q:'If a²+b²=c², a=3, b=4, find c',          ans:'5',   diff:'medium', cat:'Geometry',     timer:20 },
  { id:'q12', type:'mcq', q:'Area of circle (r=7, π≈22/7) = ?',       opts:['144','154','156','160'],   ans:'154',  diff:'medium', cat:'Geometry',     timer:25 },
  { id:'q13', type:'sub', q:'2³ + 3² = ?',                             ans:'17',  diff:'easy',   cat:'Arithmetic',   timer:15 },
  { id:'q14', type:'mcq', q:'sin(90°) = ?',                            opts:['0','1','-1','√2/2'],      ans:'1',    diff:'easy',   cat:'Trigonometry', timer:15 },
  { id:'q15', type:'sub', q:'LCM of 4 and 6 = ?',                      ans:'12',  diff:'easy',   cat:'Number Theory', timer:15 },
];
/**
 * useSocketGame
 * KEY FIXES:
 * 1. On reconnect, automatically re-registers as host so server knows new socket.id
 * 2. sessionCode stored in ref (sync) AND state (reactive)
 * 3. All send functions fall back to ref if session param is null
 */
import { useEffect, useRef, useCallback, useState } from 'react';

const SERVER_URL = 'http://localhost:3001';

let ioClient = null;
async function getIO() {
  if (!ioClient) {
    const mod = await import('socket.io-client');
    ioClient = mod.default || mod.io;
  }
  return ioClient;
}

export function useSocketGame() {
  const socketRef      = useRef(null);
  const sessionCodeRef = useRef(null);
  const listenersRef   = useRef({});

  const [connected,    setConnected]    = useState(false);
  const [sessionCode,  setSessionCode]  = useState(null);
  const [serverIP,     setServerIP]     = useState(null);
  // playerCount tracks how many phones are in each team
  const [playerCount,  setPlayerCount]  = useState({ t1: 0, t2: 0 });
  // teamsJoined = true when at least 1 player in that team
  const [teamsJoined,  setTeamsJoined]  = useState({ t1: false, t2: false });

  const createSession = useCallback(async (teamNames) => {
    if (socketRef.current) {
      socketRef.current.removeAllListeners();
      socketRef.current.disconnect();
      socketRef.current = null;
    }
    sessionCodeRef.current = null;
    setSessionCode(null);
    setTeamsJoined({ t1: false, t2: false });
    setPlayerCount({ t1: 0, t2: 0 });

    const io     = await getIO();
    const socket = io(SERVER_URL, { transports: ['websocket'], reconnection: true, reconnectionAttempts: 10, reconnectionDelay: 1000 });
    socketRef.current = socket;

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error(`Cannot reach game server at ${SERVER_URL}.\n\nRun:  npm run dev  (server starts automatically)`));
      }, 8000);

      socket.on('connect', () => {
        clearTimeout(timeout);
        setConnected(true);
        console.log('[socket] Host connected:', socket.id);

        socket.emit('create-session', { teamNames }, (res) => {
          if (res?.code) {
            sessionCodeRef.current = res.code;
            setSessionCode(res.code);
            setServerIP(res.ip);
            console.log('[socket] Session created:', res.code);
            resolve({ code: res.code, ip: res.ip, port: res.port || 3001 });
          } else {
            reject(new Error('Server failed to create session'));
          }
        });
      });

      socket.on('reconnect', () => {
        setConnected(true);
        if (sessionCodeRef.current)
          socket.emit('register-host', { session: sessionCodeRef.current });
      });

      socket.on('disconnect',    () => setConnected(false));
      socket.on('connect_error', () => {
        if (!sessionCodeRef.current) {
          clearTimeout(timeout);
          reject(new Error(`Cannot reach game server at ${SERVER_URL}.\n\nRun:  npm run dev`));
        }
      });

      // Multi-player: track count per team
      socket.on('team-joined', ({ team, playerCount: pc }) => {
        console.log('[socket] Team joined:', team, 'count:', pc);
        setPlayerCount(pc);
        setTeamsJoined({ t1: pc.t1 > 0, t2: pc.t2 > 0 });
      });

      socket.on('team-player-left', ({ playerCount: pc }) => {
        setPlayerCount(pc);
        setTeamsJoined({ t1: pc.t1 > 0, t2: pc.t2 > 0 });
      });

      socket.on('player-answer', ({ team, answer, socketId }) => {
        console.log('[socket] Answer from', team, ':', answer);
        listenersRef.current.onPlayerAnswer?.({ team, answer, socketId });
      });
    });
  }, []);

  const getSessionCode = useCallback(() => sessionCodeRef.current, []);

  const emit = useCallback((event, payload) => {
    const code = payload.session || sessionCodeRef.current;
    if (!code)                         { console.warn(`[socket] ${event}: no session code`);   return; }
    if (!socketRef.current?.connected) { console.warn(`[socket] ${event}: not connected`); return; }
    socketRef.current.emit(event, { ...payload, session: code });
  }, []);

  const sendQuestion       = useCallback((session, question, timeLeft = 25) => { console.log('[socket] sendQuestion →', question?.q); emit('send-question',   { session, question, timeLeft }); }, [emit]);
  const sendState          = useCallback((session, p)                   => emit('update-state',    { session, ...p }),                         [emit]);
  const sendAnswerFeedback = useCallback((session, team, correct)       => emit('answer-feedback', { session, team, correct }),                [emit]);
  const sendQuestionOver   = useCallback((session, correctTeam, ans)   => emit('question-over',   { session, correctTeam, correctAnswer: ans }),[emit]);
  const sendGameEnd        = useCallback((session, winner, winnerName) => emit('end-game',         { session, winner, winnerName }),            [emit]);
  const sendGameQuit       = useCallback((session)                     => emit('game-quit',        { session }),                               [emit]);
  // Between-question countdown tick — tells mobile to show a countdown overlay
  const sendBetween        = useCallback((session, countdown)          => emit('between-countdown',{ session, countdown }),                   [emit]);
  const adjustTimer        = useCallback((session, newTime)            => emit('adjust-timer',     { session, newTime }),                      [emit]);

  // Pause / Resume / Skip — new events
  const sendPause          = useCallback((session) => emit('game-pause',     { session }), [emit]);
  const sendResume         = useCallback((session) => emit('game-resume',    { session }), [emit]);
  const sendSkip           = useCallback((session) => emit('question-skip',  { session }), [emit]);

  const onPlayerAnswer     = useCallback((handler) => { listenersRef.current.onPlayerAnswer = handler; }, []);

  useEffect(() => () => { socketRef.current?.disconnect(); }, []);

  return {
    connected, sessionCode, getSessionCode, serverIP,
    teamsJoined, playerCount,
    createSession,
    sendQuestion, sendState, sendAnswerFeedback, sendQuestionOver,
    sendGameEnd, sendGameQuit, sendBetween, adjustTimer,
    sendPause, sendResume, sendSkip,
    onPlayerAnswer,
  };
}
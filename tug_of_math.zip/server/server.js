const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const os         = require('os');
const path       = require('path');

const PORT = 3001;

function getLocalIP() {
  for (const nets of Object.values(os.networkInterfaces()))
    for (const n of nets)
      if (n.family === 'IPv4' && !n.internal) return n.address;
  return '127.0.0.1';
}

const sessions = {};
const makeCode = () => Math.random().toString(36).slice(2, 8).toUpperCase();

function startServer() {
  const app    = express();
  const server = http.createServer(app);
  const io     = new Server(server, { cors: { origin: '*', methods: ['GET', 'POST'] } });

  app.use(express.static(path.join(__dirname, 'public')));
  app.get('/mobile', (_, res) => res.sendFile(path.join(__dirname, 'public', 'mobile.html')));
  app.get('/health', (_, res) => res.json({ ok: true, sessions: Object.keys(sessions) }));

  io.on('connection', (socket) => {
    console.log(`[+] ${socket.id}`);

    // ── HOST: create session ───────────────────────────────────────────
    socket.on('create-session', ({ teamNames }, cb) => {
      const code = makeCode();
      sessions[code] = {
        hostSocketIds:   new Set([socket.id]),
        // MULTI-PLAYER: each team is now a SET of socket IDs
        teams:           { t1: new Set(), t2: new Set() },
        teamNames:       teamNames || { t1: 'Team Alpha', t2: 'Team Beta' },
        currentQuestion: null,
        gamePhase:       'lobby',
        scores:          { t1: 0, t2: 0 },
        paused:          false,
      };
      socket.join(`session:${code}`);
      socket.join(`host:${code}`);
      socket.data = { role: 'host', session: code };
      console.log(`[Session] Created: ${code}`);
      cb({ code, ip: getLocalIP(), port: PORT });
    });

    socket.on('register-host', ({ session }, cb) => {
      const sess = sessions[session];
      if (!sess) return cb?.({ ok: false });
      sess.hostSocketIds.add(socket.id);
      socket.join(`session:${session}`);
      socket.join(`host:${session}`);
      socket.data = { role: 'host', session };
      cb?.({ ok: true });
    });

    // ── MOBILE: join team (multiple players allowed per team) ──────────
    socket.on('join-team', ({ session, team }, cb) => {
      const sess = sessions[session];
      if (!sess) return cb({ ok: false, error: 'Session not found' });

      const key = `t${team}`;
      sess.teams[key].add(socket.id);           // ADD to Set, not overwrite
      socket.join(`session:${session}`);
      socket.join(`player:${session}:${key}`);  // room = all players in this team
      socket.data = { role: 'player', session, team: key };

      const count = sess.teams[key].size;
      console.log(`[Join] ${socket.id} → Team ${team} in ${session} (${count} players now)`);

      io.to(`host:${session}`).emit('team-joined', {
        team: key, socketId: socket.id,
        playerCount: { t1: sess.teams.t1.size, t2: sess.teams.t2.size },
      });

      if (sess.currentQuestion) {
        socket.emit('new-question', {
          question: sess.currentQuestion, timeLeft: 25, scores: sess.scores,
          paused: sess.paused,
        });
      }

      cb({
        ok: true,
        teamName:    sess.teamNames[key],
        otherTeam:   sess.teamNames[key === 't1' ? 't2' : 't1'],
        playerCount: sess.teams[key].size,
      });
    });

    socket.on('get-current-question', ({ session }) => {
      const sess = sessions[session];
      if (sess?.currentQuestion)
        socket.emit('new-question', { question: sess.currentQuestion, timeLeft: 25, scores: sess.scores, paused: sess.paused });
    });

    // ── HOST: send question ────────────────────────────────────────────
    socket.on('send-question', ({ session, question, timeLeft }) => {
      const sess = sessions[session];
      if (!sess) return;
      sess.currentQuestion = question;
      sess.gamePhase = 'playing';
      sess.paused = false;
      const room = `session:${session}`;
      console.log(`[Q] "${question?.q}" → ${io.sockets.adapter.rooms.get(room)?.size ?? 0} sockets`);
      socket.to(room).emit('new-question', { question, timeLeft: timeLeft ?? 25, scores: sess.scores, paused: false });
    });

    // ── HOST: pause / resume ───────────────────────────────────────────
    socket.on('game-pause', ({ session }) => {
      const sess = sessions[session];
      if (!sess) return;
      sess.paused = true;
      sess.gamePhase = 'paused';
      console.log(`[Pause] ${session}`);
      socket.to(`session:${session}`).emit('game-paused');
    });

    socket.on('game-resume', ({ session }) => {
      const sess = sessions[session];
      if (!sess) return;
      sess.paused = false;
      sess.gamePhase = 'playing';
      console.log(`[Resume] ${session}`);
      socket.to(`session:${session}`).emit('game-resumed');
    });

    // ── HOST: skip question ────────────────────────────────────────────
    socket.on('question-skip', ({ session }) => {
      const sess = sessions[session];
      if (!sess) return;
      console.log(`[Skip] ${session}`);
      socket.to(`session:${session}`).emit('question-skipped');
    });

    // ── HOST: adjust timer ─────────────────────────────────────────────
    // ── HOST: between-question countdown tick ────────────────────────────
    socket.on('between-countdown', ({ session, countdown }) => {
      socket.to(`session:${session}`).emit('between-countdown', { countdown });
    });

    socket.on('adjust-timer', ({ session, newTime }) => {
      if (!sessions[session]) return;
      socket.to(`session:${session}`).emit('timer-adjusted', { newTime });
    });

    // ── HOST: send question + state updates ───────────────────────────
    socket.on('update-state', ({ session, ropePos, scores, phase, lastWinner }) => {
      const sess = sessions[session];
      if (!sess) return;
      if (scores) sess.scores = scores;
      if (phase)  sess.gamePhase = phase;
      socket.to(`session:${session}`).emit('state-update', { ropePos, scores: sess.scores, phase, lastWinner });
    });

    socket.on('question-over', ({ session, correctTeam, correctAnswer }) => {
      socket.to(`session:${session}`).emit('question-result', { correctTeam, correctAnswer });
    });

    socket.on('end-game', ({ session, winner, winnerName }) => {
      socket.to(`session:${session}`).emit('game-over', { winner, winnerName });
      delete sessions[session];
      console.log(`[Session] Ended: ${session}`);
    });

    socket.on('game-quit', ({ session }) => {
      socket.to(`session:${session}`).emit('game-quit');
      delete sessions[session];
      console.log(`[Session] Quit: ${session}`);
    });

    // ── MOBILE: submit answer ──────────────────────────────────────────
    // First correct answer from a team wins — server deduplicates per question
    socket.on('submit-answer', ({ session, team, answer }) => {
      const sess = sessions[session];
      if (!sess) return;
      console.log(`[Answer] ${team} (${socket.id}): "${answer}" in ${session}`);
      // Forward to host — host decides if it's first/correct
      io.to(`host:${session}`).emit('player-answer', { team, answer, socketId: socket.id });
    });

    // ── HOST: send answer feedback to ONE team (all players in that team) ─
    socket.on('answer-feedback', ({ session, team, correct }) => {
      // io.to(room) broadcasts to ALL sockets in the team room
      io.to(`player:${session}:${team}`).emit('answer-feedback', { correct });
    });

    // ── Disconnect ─────────────────────────────────────────────────────
    socket.on('disconnect', () => {
      const { role, session, team } = socket.data || {};
      if (role === 'player' && session && sessions[session]) {
        sessions[session].teams[team]?.delete(socket.id);
        const remaining = sessions[session].teams[team]?.size ?? 0;
        io.to(`host:${session}`).emit('team-player-left', {
          team,
          playerCount: { t1: sessions[session].teams.t1.size, t2: sessions[session].teams.t2.size },
          remaining,
        });
      }
      console.log(`[-] ${socket.id} (${role || '?'})`);
    });
  });

  server.listen(PORT, '0.0.0.0', () => {
    const ip = getLocalIP();
    console.log('\n╔══════════════════════════════════════╗');
    console.log('║       Math Arena — Game Server       ║');
    console.log('╠══════════════════════════════════════╣');
    console.log(`║  Local:   http://localhost:${PORT}      ║`);
    console.log(`║  Network: http://${ip}:${PORT}   ║`);
    console.log('╚══════════════════════════════════════╝\n');
  });

  return { server, io };
}

if (require.main === module) startServer();
module.exports = { startServer, PORT, getLocalIP };